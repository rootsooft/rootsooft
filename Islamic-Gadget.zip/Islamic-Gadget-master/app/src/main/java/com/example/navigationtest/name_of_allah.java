package com.example.navigationtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class name_of_allah extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name_of_allah);
    }
}
